title: Docker拉取镜像Client.Timeout exceeded while awaiting headers
date: '2019-05-29 16:02:45'
updated: '2019-05-29 16:04:07'
tags: [docker]
permalink: /articles/2019/05/29/1559116965815.html
---
使用docker 拉官方镜像的时候，出现下面的错误：

```
  net/http: request canceled while waiting for connection (Client.Timeout exceeded while awaiting headers)

```
这是由于Docker Hub服务器在国外，在国内访问速度过慢或者是被墙了导致请求超时。
### 解决方案
#### 方法一：配置加速器
修改/etc/docker/daemon.json (要使用终极权限才能修改，Linux不同版本写法不一样)，如果没有这个文件就自己创建一个

* 使用命令编辑文件
```
vim /etc/docker/daemon.json
```
* 在文件中添加以下内容
```
{  
	"registry-mirrors":  ["https://docker.mirrors.aliyuncs.com"]  
}
```
> 加速器的镜像也可以改为下面的源
  阿里云的镜像： [https://docker.mirrors.aliyuncs.com](https://docker.mirrors.aliyuncs.com/)
docker-cn镜像：[https://registry.docker-cn.com](https://registry.docker-cn.com/)
腾讯云的镜像： [https://mirror.ccs.tencentyun.com](https://mirror.ccs.tencentyun.com/)
 
* 重启守护进程
```
systemctl daemon-reload
systemctl restart docker
```
#### 方法二：设置代理翻墙
挂上vpn，轻松连接
